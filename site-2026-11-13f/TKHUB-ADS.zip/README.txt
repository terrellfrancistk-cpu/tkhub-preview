Black boards. Letter logos. Name + domain. CTA TKHUB.APP. JPEG RGB for Blip.
