TK HUB ADS — exact sizes, right file type
Domain on every board: tkhub.app

JPG = display / social / programmatic (smaller, standard).
PNG = lossless master for print / outdoor (1400x400 + 1080x1920).

Folders are the size. File name is the campaign.

Campaigns: 8
Files: 152

Campaigns
01 Zilt + Afterglow
02 Our People + WRACE
03 RADR + NOIR
04 Booked + Curb
05 4AM Files
06 TK Hub house
07 TK Works
08 TK Dental
